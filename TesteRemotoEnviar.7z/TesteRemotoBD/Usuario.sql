CREATE TABLE Usuario(
	[ID] [int] IDENTITY(1,1) NOT NULL,	
	[Nome] [varchar](200) NOT NULL,
	[DataNascimento] [DATETIME] NOT NULL,
	[Email] [varchar](150) NULL,
	[Sexo] [char](1) NOT NULL,
	[Ativo] BIT NULL,
 CONSTRAINT [PK_Usuario] PRIMARY KEY NONCLUSTERED 
(	[ID] ASC
)
) 
GO
