CREATE TABLE Sexo(
	[SexoId] [int] IDENTITY(1,1) NOT NULL,	
	[Descricao] [varchar](15) NOT NULL,
 CONSTRAINT [PK_Sexo] PRIMARY KEY NONCLUSTERED 
(	[SexoId] ASC
)
) 
GO
