﻿using System;
using System.ComponentModel.DataAnnotations;

namespace TesteRemoto.Models
{
    public class Usuario
    {
        public int ID { get; set; }
        [Required]
        [StringLength(200, MinimumLength = 3)]
        public string Nome { get; set; }
        [Required]
        [Display(Name = "Data de Nascimento")]
        [DataType(DataType.Date)]
        public DateTime DataNascimento { get; set; }
        [Display(Name = "e-mail")]
        public string Email { get; set; }
        [Required]
        public string Sexo { get; set; }
        public bool Ativo { get; set; }
    }
}
