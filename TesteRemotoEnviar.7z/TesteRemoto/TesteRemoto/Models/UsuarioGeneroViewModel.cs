﻿using Microsoft.AspNetCore.Mvc.Rendering;
using System.Collections.Generic;

namespace TesteRemoto.Models
{
    public class UsuarioGeneroViewModel
    {
        public List<Usuario> usuarios;
        public SelectList generos;        
        public string usuarioGenero { get; set; }
    }
}
