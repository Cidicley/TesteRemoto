﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using TesteRemoto.Models;

namespace TesteRemoto.Models
{
    public class TesteRemotoContext : DbContext
    {
        public TesteRemotoContext (DbContextOptions<TesteRemotoContext> options)
            : base(options)
        {
        }
        

        public DbSet<TesteRemoto.Models.Usuario> Usuario { get; set; }
    }
}
